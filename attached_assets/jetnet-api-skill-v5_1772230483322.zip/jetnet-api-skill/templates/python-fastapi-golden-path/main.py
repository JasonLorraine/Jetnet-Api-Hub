"""
main.py -- JETNET FastAPI Golden Path Starter

Exposes:
    GET /                       -- health check
    GET /aircraft/{tail}        -- tail number lookup via getRegNumber

Run:
    python main.py
    # or: uvicorn main:app --reload

Docs: http://localhost:8000/docs
"""

import os
from contextlib import asynccontextmanager
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

load_dotenv()

# ---------------------------------------------------------------------------
# Lazy session import -- handles the case where session.py is in this dir
# or in src/jetnet/ depending on project layout
# ---------------------------------------------------------------------------
try:
    from jetnet.session import login, ensure_session, jetnet_request, SessionState
except ImportError:
    import sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))
    from jetnet.session import login, ensure_session, jetnet_request, SessionState


# ---------------------------------------------------------------------------
# App startup: authenticate once and store session state
# ---------------------------------------------------------------------------

_session: Optional[SessionState] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _session
    print("Logging in to JETNET ...")
    _session = login()
    print(f"JETNET session ready. Token issued at {_session.created_at:.0f}")
    yield
    # Cleanup on shutdown (nothing required)


app = FastAPI(
    title="JETNET Tail Lookup API",
    description="Minimal FastAPI wrapper around the JETNET Jetnet Connect API.",
    version="1.0.0",
    lifespan=lifespan,
)


def get_session() -> SessionState:
    """Return a valid session, refreshing if stale."""
    global _session
    if _session is None:
        _session = login()
    _session = ensure_session(_session)
    return _session


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@app.get("/", tags=["Health"])
def health():
    """Health check endpoint."""
    session = get_session()
    return {
        "status": "ok",
        "token_age_seconds": int(__import__("time").time() - session.created_at),
    }


@app.get("/aircraft/{tail}", tags=["Aircraft"])
def lookup_tail(tail: str):
    """
    Look up an aircraft by tail number (registration number).

    Returns normalized owner, operator, and contact information.

    - **tail**: FAA registration number, e.g. N12345 (case-insensitive)
    """
    session = get_session()
    tail = tail.strip().upper()

    try:
        raw = jetnet_request(
            "GET",
            f"/api/Aircraft/getRegNumber/{tail}/{{apiToken}}",
            session,
        )
    except ValueError as e:
        raise HTTPException(status_code=502, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"JETNET error: {e}")

    ac = raw.get("aircraftresult")
    if not ac:
        raise HTTPException(
            status_code=404,
            detail=f"Tail number '{tail}' not found in JETNET.",
        )

    # Normalize relationships (getRegNumber uses flat companyrelation schema)
    rels = ac.get("companyrelationships", [])
    owner    = next((r for r in rels if r.get("companyrelation") == "Owner"), None)
    operator = next((r for r in rels if r.get("companyrelation") == "Operator"), None)

    def flatten_contact(rel: dict) -> dict:
        if not rel:
            return {}
        first = rel.get("contactfirstname") or ""
        last  = rel.get("contactlastname") or ""
        return {
            "company_id":   rel.get("companyid"),
            "company_name": rel.get("companyname"),
            "city":         rel.get("companycity"),
            "state":        rel.get("companystateabbr") or rel.get("companystate"),
            "country":      rel.get("companycountry"),
            "phone":        rel.get("companyofficephone"),
            "email":        rel.get("companyemail") or None,
            "contact_name": f"{first} {last}".strip() or None,
            "contact_title": rel.get("contacttitle"),
            "contact_email": rel.get("contactemail") or None,
            "contact_phone": rel.get("contactbestphone"),
        }

    aircraft_id = ac.get("aircraftid")
    page_url = (
        f"http://www.jetnetevolution.com/DisplayAircraftDetail.aspx?acid={aircraft_id}"
        if aircraft_id else None
    )

    return {
        "aircraft_id":    aircraft_id,
        "tail_number":    ac.get("regnbr"),
        "make":           ac.get("make"),
        "model":          ac.get("model"),
        "year_mfr":       ac.get("yearmfr"),
        "year_delivered": ac.get("yeardlv"),
        "category_size":  ac.get("categorysize"),
        "weight_class":   ac.get("weightclass"),
        "make_type":      ac.get("maketype"),
        "usage":          ac.get("usage"),
        "for_sale":       bool(ac.get("forsale")),
        "base_icao":      ac.get("baseicao"),
        "base_airport":   ac.get("baseairport"),
        "base_country":   ac.get("basecountry"),
        "owner":          flatten_contact(owner) if owner else None,
        "operator":       flatten_contact(operator) if operator else None,
        "jetnet_page_url": page_url,
        "data_source":    "JETNET",
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
