# JETNET FastAPI Golden Path Starter

A minimal FastAPI service that authenticates with the JETNET API and exposes
a `/aircraft/{tail}` endpoint. Start here for:
- Backend services that power a frontend app
- CRM enrichment webhooks
- Internal tooling for brokers and charter operators

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env and add your JETNET credentials

python main.py
# API running at http://localhost:8000
# Docs at http://localhost:8000/docs
```

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Health check |
| GET | `/aircraft/{tail}` | Look up aircraft by tail number |

## Environment variables

| Variable | Required | Description |
|---|---|---|
| `JETNET_EMAIL` | Yes | Your JETNET email (sent as `emailAddress` in API) |
| `JETNET_PASSWORD` | Yes | Your JETNET password |
| `JETNET_BASE_URL` | No | Default: `https://customer.jetnetconnect.com` |

## File structure

```
main.py                 -- FastAPI app + routes
jetnet/
  session.py            -- Auth + request helper (from src/jetnet/session.py)
requirements.txt
.env.example
README.md
```

## JETNET response notes

- `aircraftresult` is the top-level key (not `aircraft`)
- `companyrelationships` uses a flat schema: `companyrelation`, `companyname`, `contactfirstname`, etc.
- Token lifetime: ~8 hours. The session helper auto-refreshes.
- See `docs/response-shapes.md` in the skill root for normalization patterns.
