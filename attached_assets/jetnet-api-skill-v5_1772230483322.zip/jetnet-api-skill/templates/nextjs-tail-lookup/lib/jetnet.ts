/**
 * lib/jetnet.ts -- JETNET auth + getRegNumber for Next.js
 *
 * All calls are server-side only. Never import this in client components.
 */

const BASE_URL =
  process.env.JETNET_BASE_URL ?? 'https://customer.jetnetconnect.com'

let cachedBearer: string | null = null
let cachedToken: string | null = null
let tokenIssuedAt = 0
const TOKEN_TTL_MS = 7 * 60 * 60 * 1000 // 7 hours

/**
 * Log in and cache tokens. Re-logins if token is older than 7 hours.
 * CRITICAL: field is "emailAddress" with capital A.
 */
async function getTokens(): Promise<{ bearer: string; token: string }> {
  const now = Date.now()
  if (cachedBearer && cachedToken && now - tokenIssuedAt < TOKEN_TTL_MS) {
    return { bearer: cachedBearer, token: cachedToken }
  }

  const email = process.env.JETNET_EMAIL
  const password = process.env.JETNET_PASSWORD
  if (!email || !password) {
    throw new Error('JETNET_EMAIL and JETNET_PASSWORD must be set')
  }

  const res = await fetch(`${BASE_URL}/api/Admin/APILogin`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    // CRITICAL: "emailAddress" -- capital A. NOT "email" or "emailaddress".
    body: JSON.stringify({ emailAddress: email, password }),
    cache: 'no-store',
  })

  if (!res.ok) {
    throw new Error(`JETNET login HTTP ${res.status}`)
  }

  const data = (await res.json()) as Record<string, unknown>
  const status = String(data.responsestatus ?? '')
  if (status.toUpperCase().startsWith('ERROR') || status.toUpperCase().startsWith('INVALID')) {
    throw new Error(`JETNET login error: ${status}`)
  }

  cachedBearer = String(data.bearerToken ?? '')
  cachedToken = String(data.apiToken ?? '')
  tokenIssuedAt = now

  if (!cachedBearer || !cachedToken) {
    throw new Error(`JETNET login returned no tokens. Response: ${JSON.stringify(data).slice(0, 200)}`)
  }

  return { bearer: cachedBearer, token: cachedToken }
}

/**
 * Look up an aircraft by tail number (registration number).
 * Returns the raw JETNET response dict.
 *
 * Tail number is case-insensitive on the JETNET server.
 */
export async function getRegNumber(
  tailNumber: string
): Promise<Record<string, unknown>> {
  const { bearer, token } = await getTokens()
  const tail = tailNumber.trim().toUpperCase()

  const res = await fetch(
    `${BASE_URL}/api/Aircraft/getRegNumber/${tail}/${token}`,
    {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${bearer}`,
        'Content-Type': 'application/json',
      },
      cache: 'no-store',
    }
  )

  if (!res.ok) {
    throw new Error(`getRegNumber HTTP ${res.status}`)
  }

  const data = (await res.json()) as Record<string, unknown>
  const status = String(data.responsestatus ?? '')
  if (status.toUpperCase().startsWith('ERROR') || status.toUpperCase().startsWith('INVALID')) {
    throw new Error(`JETNET error: ${status}`)
  }

  return data
}
