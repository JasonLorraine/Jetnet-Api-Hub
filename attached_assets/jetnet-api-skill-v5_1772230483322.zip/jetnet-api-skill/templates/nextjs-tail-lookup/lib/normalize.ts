/**
 * lib/normalize.ts -- JETNET raw response -> GoldenPathResult
 *
 * Normalizes the flat companyrelationships schema from getRegNumber
 * into a consistent shape for UI components.
 */

export interface ContactCard {
  contactId: number | null
  firstName: string | null
  lastName: string | null
  fullName: string
  title: string | null
  email: string | null
  phone: string | null
}

export interface CompanyCard {
  companyId: number | null
  name: string | null
  city: string | null
  state: string | null
  country: string | null
  phone: string | null
  email: string | null
  contact: ContactCard | null
}

export interface GoldenPathResult {
  aircraftId: number
  tailNumber: string
  make: string
  model: string
  yearMfr: number
  yearDelivered: number | null
  categorySize: string | null
  weightClass: string | null
  makeType: string | null
  usage: string | null
  forSale: boolean
  marketStatus: string | null
  baseIcao: string | null
  baseAirport: string | null
  baseCountry: string | null
  owner: CompanyCard | null
  operator: CompanyCard | null
  jetnetPageUrl: string | null
  dataSource: 'JETNET'
}

type RawRel = Record<string, unknown>

function contactFromFlat(rel: RawRel): ContactCard {
  const first = String(rel.contactfirstname ?? '')
  const last = String(rel.contactlastname ?? '')
  return {
    contactId: rel.contactid ? Number(rel.contactid) : null,
    firstName: first || null,
    lastName: last || null,
    fullName: [first, last].filter(Boolean).join(' '),
    title: (rel.contacttitle as string) ?? null,
    email: (rel.contactemail as string) || null,
    phone: (rel.contactbestphone as string) ?? null,
  }
}

function companyFromFlat(rel: RawRel): CompanyCard {
  return {
    companyId: rel.companyid ? Number(rel.companyid) : null,
    name: (rel.companyname as string) ?? null,
    city: (rel.companycity as string) ?? null,
    state: (rel.companystateabbr as string) ?? (rel.companystate as string) ?? null,
    country: (rel.companycountry as string) ?? null,
    phone: (rel.companyofficephone as string) ?? null,
    email: (rel.companyemail as string) || null,
    contact: contactFromFlat(rel),
  }
}

/**
 * Normalize a raw getRegNumber response into GoldenPathResult.
 */
export function normalize(raw: Record<string, unknown>): GoldenPathResult {
  const ac = (raw.aircraftresult as Record<string, unknown>) ?? raw
  const rels = (ac.companyrelationships as RawRel[]) ?? []

  // getRegNumber uses "companyrelation" (NOT "relationtype")
  const ownerRel = rels.find(r => r.companyrelation === 'Owner') ?? null
  const opRel = rels.find(r => r.companyrelation === 'Operator') ?? null

  const aircraftId = Number(ac.aircraftid)
  const pageUrl = aircraftId
    ? `http://www.jetnetevolution.com/DisplayAircraftDetail.aspx?acid=${aircraftId}`
    : null

  return {
    aircraftId,
    tailNumber: String(ac.regnbr ?? ''),
    make: String(ac.make ?? ''),
    model: String(ac.model ?? ''),
    yearMfr: Number(ac.yearmfr),
    yearDelivered: ac.yeardlv ? Number(ac.yeardlv) : null,
    categorySize: (ac.categorysize as string) ?? null,
    weightClass: (ac.weightclass as string) ?? null,
    makeType: (ac.maketype as string) ?? null,
    usage: (ac.usage as string) ?? null,
    forSale: Boolean(ac.forsale),
    marketStatus: null,
    baseIcao: (ac.baseicao as string) ?? null,
    baseAirport: (ac.baseairport as string) ?? null,
    baseCountry: (ac.basecountry as string) ?? null,
    owner: ownerRel ? companyFromFlat(ownerRel) : null,
    operator: opRel ? companyFromFlat(opRel) : null,
    jetnetPageUrl: pageUrl,
    dataSource: 'JETNET',
  }
}
