# JETNET API Hub -- Start Here

Welcome. This hub gives you three paths to working JETNET integrations.
Pick the one that matches what you are building.

---

## Which path are you on?

### Path A -- Demo UI (tail-number lookup, market snapshot)
**You want:** A web page where someone types a tail number and sees owner, operator, contact info, and market status.

**Start with:**
1. `templates/nextjs-tail-lookup/` -- Next.js 14 App Router starter
2. `docs/response-shapes.md` -- understand AircraftCard, CompanyCard, GoldenPathResult
3. `prompts/01_golden_path_tail_lookup_app.md` -- paste into Cursor/Copilot to scaffold fast

**Core endpoint:** `GET /api/Aircraft/getRegNumber/{regnbr}/{apiToken}`

---

### Path B -- Bulk Data / Pipeline (fleet monitoring, market intelligence feed)
**You want:** A script or service that pulls thousands of aircraft records, detects changes, writes to a database or CRM.

**Start with:**
1. `templates/python-fastapi-golden-path/` -- FastAPI + paginator starter
2. `scripts/paginate.py` -- generic pagination helper for all paged endpoints
3. `prompts/04_bulk_export_pipeline.md` -- paste into Cursor to scaffold the hourly polling loop

**Core endpoint:** `POST /api/Aircraft/getBulkAircraftExportPaged/{apiToken}/{pagesize}/{page}`

---

### Path C -- CRM Enrichment (FBO lead gen, charter sales prospecting)
**You want:** To take a list of tail numbers or aircraft types and enrich your CRM with owner contacts, chief pilot details, fleet data.

**Start with:**
1. `references/vertical-playbooks.md` -- Playbooks 7 (FBO), 8 (Dealer-Broker), 9 (History Search)
2. `prompts/02_fbo_airport_activity_leads.md` -- FBO ramp-to-lead enrichment prompt
3. `scripts/paginate.py` -- use `get_all_history()` for comp search

**Core endpoints:** `getRegNumber`, `getRelationships` with aclist, `getHistoryListPaged`

---

## Authentication (every path)

All three paths use the same two-token pattern. Do this first:

```python
import os, requests

# CRITICAL: field is "emailAddress" with capital A
r = requests.post(
    "https://customer.jetnetconnect.com/api/Admin/APILogin",
    json={"emailAddress": os.environ["JETNET_EMAIL"],
          "password":      os.environ["JETNET_PASSWORD"]}
)
data = r.json()
bearer = data["bearerToken"]   # goes in Authorization: Bearer header
token  = data["apiToken"]      # goes in URL path
```

Or use the session helper (Path A: `src/jetnet/session.ts`, Path B/C: `src/jetnet/session.py`) which handles token refresh automatically.

**Token lifetime:** ~8 hours. Set `JETNET_EMAIL` and `JETNET_PASSWORD` as environment variables. Never hardcode credentials.

---

## Directory Map

```
jetnet-api-skill/
├── START_HERE.md               <-- you are here
├── SKILL.md                    <-- AI assistant instructions (primary skill file)
│
├── prompts/                    # Cursor / Copilot prompt recipes (Item 4)
│   ├── README.md
│   ├── 01_golden_path_tail_lookup_app.md
│   ├── 02_fbo_airport_activity_leads.md
│   ├── 03_fleet_watchlist_alerts.md
│   └── 04_bulk_export_pipeline.md
│
├── templates/                  # Working starter templates (Item 5)
│   ├── nextjs-tail-lookup/     # Path A: Next.js 14 App Router
│   └── python-fastapi-golden-path/  # Path B/C: FastAPI + paginator
│
├── src/jetnet/                 # Reusable session helpers (Item 6)
│   ├── session.py              # Python: login, ensureSession, jetnetRequest
│   └── session.ts              # TypeScript: login, ensureSession, jetnetRequest
│
├── docs/                       # Normalized response contracts (Item 7)
│   └── response-shapes.md      # AircraftCard, CompanyCard, GoldenPathResult
│
├── scripts/                    # Utility scripts
│   ├── paginate.py             # Generic paginator for all paged endpoints
│   ├── validate_payload.py     # Request body validator
│   └── token_probe.py          # Measure actual token lifetime
│
├── examples/                   # Known-good request/response pairs
│   ├── README.md               # Index of all examples
│   ├── tail-lookup.json
│   ├── history-transaction-search.json
│   ├── bulk-export-hourly.json
│   └── ... (10 more)
│
└── references/                 # Deep-reference docs
    ├── quick-reference.md      # Endpoint table, schema comparison, common mistakes
    ├── auth-guide.md           # Auth deep-dive
    └── vertical-playbooks.md   # 9 industry use-case playbooks
```

---

## Quick diagnostic: is my token working?

```bash
# Run from repo root
JETNET_EMAIL=you@example.com JETNET_PASSWORD=secret \
  python scripts/token_probe.py
```

Or from Python:

```python
from src.jetnet.session import login, get_account_info
session = login()
info = get_account_info(session)
print(info.get("responsestatus"))  # should be "SUCCESS"
```

---

## Common first-timer mistakes

| Mistake | Fix |
|---|---|
| `email` instead of `emailAddress` | Capital A: `{"emailAddress": "..."}` |
| Treating `maxpages: 0` as an error | `maxpages=0` means single-page result |
| `MM/DD/YYYY` for hourly polling | Use `MM/DD/YYYY HH:MM:SS` for getBulkExport |
| Forgetting Bearer header | All endpoints need `Authorization: Bearer {bearerToken}` |
| Token expires silently | Use `ensure_session()` / `ensureSession()` helpers |
| Wrong transtype string | Request: `"FullSale"` (category). Response: `"Full Sale - Retail to Retail"` |

Full list: `references/quick-reference.md` -- Common Mistakes section.
