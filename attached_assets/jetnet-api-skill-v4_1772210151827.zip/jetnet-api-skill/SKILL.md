---
name: jetnet-api
description: >
  Expert guide for working with the JETNET API (Jetnet Connect). Use whenever
  the user wants to call JETNET endpoints, look up aircraft by tail number,
  query ownership or fleet data, retrieve market trends, build an app or
  integration (iPhone MVP, Replit, CRM, data pipeline), understand auth tokens,
  paginate results, or work with modlist/aclist/modelid.
  Trigger on: JETNET, Jetnet Connect, bearerToken, apiToken, securityToken,
  getRegNumber, getHistoryList, getFlightData, getRelationships,
  getCondensedSnapshot, getModelMarketTrends, getModelIntelligence,
  getAircraftList, getBulkAircraftExport, tail number lookup, modlist, aclist,
  aviation database, aircraft ownership, business aviation data.
  Do NOT use for: general aviation weather, FAA regulatory filings, FlightAware
  or FlightRadar real-time tracking, ICAO rule lookups, or non-JETNET APIs.
---

# JETNET API (Jetnet Connect) Skill

Get to first success fast, then expand. The Golden Path (tail lookup + pictures +
relationships + flight activity) solves the majority of real customer needs.

**Skill vs MCP:** Use this skill for operational guidance, workflow context, and
payload generation. Use an MCP server if you need live JETNET calls from a
cross-LLM pipeline or a shared integration server. MCP loads all tool metadata
up front (often 20k+ tokens); this skill uses progressive disclosure and stays
lean in context.

**Base URL:** `https://customer.jetnetconnect.com`
**Swagger:** `https://customer.jetnetconnect.com/swagger/index.html`

---

## Two-Tier Model -- Read This First

**Tier A -- Interactive (Tier A = App / Real-time)**
Tail lookup, owner/operator, pictures, quick flight summary, CRM enrichment.
One aircraft at a time. Low volume. User is waiting.

**Tier B -- Bulk / Data Engineering**
Nightly sync, history exports, analytics pipelines, large event windows.
Always paged. Run async. Never drive a live UI off these.

If building an app or a script for a salesperson: Tier A.
If a customer asks about bulk export, nightly refresh, or history across thousands
of aircraft: Tier B.

---

## Authentication

```http
POST https://customer.jetnetconnect.com/api/Admin/APILogin
Content-Type: application/json

{ "emailAddress": "YOUR_EMAIL@example.com", "password": "YOUR_PASSWORD" }
```

**`emailAddress` has a capital A.** This is the single most common auth mistake.

Response returns `bearerToken` and `apiToken` (also called `securityToken` in
some docs -- same field).

Every subsequent call:
- Header: `Authorization: Bearer {bearerToken}`
- URL path: `{apiToken}` replaces `{apiToken}` or `{securityToken}` in the path

The `apiToken` goes **in the URL path only** -- never in headers or JSON body.

On `ERROR: INVALID SECURITY TOKEN`: re-login and retry once. Never loop.

**Token lifetime:** Tokens expire after approximately 8 hours of inactivity.
For 24/7 pipelines (hourly polling, nightly syncs), store token issue time and
proactively re-login after 7 hours rather than waiting for a failure. Pattern:

```python
import time
token_issued = 0
TOKEN_TTL = 7 * 3600  # refresh after 7h (tokens last ~8h)

def get_tokens():
    global bearer, token, token_issued
    if time.time() - token_issued > TOKEN_TTL:
        bearer, token = login(os.environ["JETNET_EMAIL"], os.environ["JETNET_PASSWORD"])
        token_issued = time.time()
    return bearer, token
```

```python
import requests, os
BASE = "https://customer.jetnetconnect.com"

def login(email, password):
    r = requests.post(f"{BASE}/api/Admin/APILogin",
                      json={"emailAddress": email, "password": password})
    r.raise_for_status()
    d = r.json()
    return d["bearerToken"], d["apiToken"]

def api(method, path, bearer, token, body=None):
    url = f"{BASE}{path}".replace("{apiToken}", token)
    headers = {"Authorization": f"Bearer {bearer}", "Content-Type": "application/json"}
    r = requests.request(method, url, headers=headers, json=body)
    r.raise_for_status()
    result = r.json()
    if "ERROR" in result.get("responsestatus", "").upper():
        raise ValueError(f"JETNET error: {result['responsestatus']}")
    return result

bearer, token = login(os.environ["JETNET_EMAIL"], os.environ["JETNET_PASSWORD"])
```

---

## The Golden Path (Tier A)

```
1. getRegNumber/{reg}/{apiToken}           → GET  → aircraftid
2. getPictures/{aircraftid}/{apiToken}     → GET  → pictures[]
   getRelationships/{apiToken}             → POST → relationships[]
   getFlightDataPaged/{apiToken}/100/1     → POST → flightdata[]   (parallel)
3. getHistoryListPaged/{apiToken}/100/1    → POST → history[]      (lazy)
   getEventListPaged/{apiToken}/100/1      → POST → events[]       (lazy)
```

Never call JETNET from a mobile client or browser. Always proxy through a backend
that holds both tokens. For full Node.js + Python app examples: `references/buildkit.md`.

---

## modlist, aclist, and modelid

`modlist` = array of integer model IDs. Filters by aircraft type across list,
history, and flight endpoints.
```json
"modlist": [145, 634]     // G550 and G600 only
"modlist": []             // no model filter
```

`aclist` = array of integer aircraft IDs. Targets specific known aircraft.
```json
"aclist": [128228, 242781]
"aclist": []              // no aircraft filter
```

Use `modlist` to filter by type. Use `aclist` when you already have specific IDs.
Model IDs: check `Custom export 6.xlsx` or call `getAircraftModelList`.
ID system reference: `references/id-glossary.md`.

---

## Pagination

Use `Paged` variants for history, flight data, events, bulk export, company and
contact lists. Non-paged versions time out on large datasets.

URL pattern:
```
POST .../getHistoryListPaged/{apiToken}/{pagesize}/{page}
```

- `page` is **1-based** (first page = 1, not 0)
- Loop until `page >= data["maxpages"]`
- `count` = records on this page (not total)
- `responsestatus` on paged calls = `"SUCCESS: PAGE [ 1 of 428 ]"` -- use `maxpages` for loop control, not this string

```python
LIST_KEYS = {"history","flightdata","events","aircraft",
             "aircraftowneroperators","companylist","contactlist","relationships",
             "aircraftcompfractionalrefs"}

def get_all_pages(bearer, token, paged_path, body, pagesize=100):
    results, page = [], 1
    while True:
        data = api("POST", f"{paged_path}/{pagesize}/{page}", bearer, token, body)
        results.extend(next((v for k,v in data.items() if isinstance(v,list) and k in LIST_KEYS), []))
        if page >= data.get("maxpages", 1): break
        page += 1
    return results
```

---

## Endpoint Quick Reference

Full parameter list: `references/endpoints.md`
Known-good payloads: `examples/`
Industry playbooks: `references/vertical-playbooks.md`

### Aircraft
| Endpoint | Method | Paged? | Response key |
|----------|--------|--------|-------------|
| `getRegNumber/{reg}/{apiToken}` | GET | No | `aircraftresult` (object) |
| `getAircraftList/{apiToken}` | POST | **No** | `aircraft` |
| `getHistoryList` | POST | **Yes** | `history` |
| `getFlightData` | POST | **Yes** | `flightdata` |
| `getEventList` | POST | **Yes** | `events` |
| `getRelationships/{apiToken}` | POST | No | `relationships` |
| `getCondensedOwnerOperators` | POST | Yes | `aircraftowneroperators` |
| `getBulkAircraftExport` | POST | **Always** | `aircraft` |
| `getAcCompanyFractionalReportPaged` | POST | **Always** | `aircraftcompfractionalrefs` |
| `getPictures/{id}/{apiToken}` | GET | No | `pictures` |

### Aircraft -- Transaction Reports
| Endpoint | Method | Paged? | Response key |
|----------|--------|--------|-------------|
| `getAcSellerPurchaserReportPaged` | POST | **Always** | `sellerPurchaserRefs` |
| `getHistoryListPaged` | POST | **Yes** | `history` |

### Model
| Endpoint | Purpose | Key filter |
|----------|---------|-----------|
| `getModelMarketTrends` | For-sale count, asking price, days on market by month | `modlist`, `displayRange` |
| `getModelPerformanceSpecs` | Range, speed, cabin, payload specs | `modlist` |
| `getModelOperationCosts` | Annual operating costs | `modlist`, `annualhours`, `fuelprice` |
| `getModelIntelligence` | Aggregated analytics: fleet counts, utilization, market metrics | `modlist`, `minrange`, `maxrange`, `minpax`, `maxpax`, `minyear`, `maxyear` |

### Company / Contact
`getCompanyList` (paged), `getCompany/{id}`, `getContacts/{id}`,
`getContactList` (paged), `getContact/{id}`, `getAircraftrelationships/{id}`

### Utility
`getAircraftModelList`, `getAircraftMakeList`, `getEventCategories`,
`getEventTypes`, `getCountryList`, `getAirportList`, `getProductCodes`

---

## getRelationships -- Two Patterns

**Single aircraft (Tier A, Golden Path):**
```json
{ "aircraftid": 211461, "aclist": [], "modlist": [], "actiondate": "", "showHistoricalAcRefs": false }
```

**Bulk fleet (Tier B -- many IDs at once):**
```json
{ "aclist": [7103, 8542, 11200], "modlist": [], "actiondate": "", "showHistoricalAcRefs": false }
```

Response key is `relationships`. Fields: `aircraftid`, `regnbr`, `name` (company),
`relationtype` (`"Owner"`, `"Operator"`, etc.), `relationseqno`, nested `company` object.
Two counts: `aircraftcount` (distinct aircraft) and `count` (total relationship records).

Full response shape: `examples/relationships-bulk.json`

---

## Response Structure and companyrelationships

HTTP 200 does not mean success -- always check `responsestatus` for `"ERROR"`.

`companyrelationships` structure **differs by endpoint** -- this causes real bugs:

| Endpoint | Schema | Relation field | Relation values |
|----------|--------|---------------|----------------|
| `getRegNumber` | **Flat** -- prefixed fields (`companyname`, `contactfirstname`) | `companyrelation` | `"Owner"`, `"Operator"`, `"Chief Pilot"` |
| `getAircraftList` | Not present | -- | -- |
| `getHistoryList` / `getRelationships` | **Nested** -- `company: {}`, `contact: {}` sub-objects | `relationtype` | `"Owner"`, `"Operator"`, `"Seller"`, `"Purchaser"`, `"Seller's Broker"` |
| `getBulkAircraftExport` | **Flat prefixed by role** -- `owr*`, `opr*`, `chp*`, `excbrk1*`, `addl1*` | Field prefix | Owner=`owr*`, Operator=`opr*`, Chief Pilot=`chp*` |
| `getAcCompanyFractionalReportPaged` | **Flat** -- top-level `comp*` and `contact*` fields | `relation` | `"Owner"`, `"Flight Department"`, `"Certificate Holder"` |

Full response shapes: `examples/`

---

## Common Mistakes

- `emailAddress` has a capital A -- not `email` or `emailaddress`
- `apiToken` in the URL path only -- never in headers or body
- Empty `aclist: []` means no filter, not empty results -- be intentional
- HTTP 200 does not mean success -- check `responsestatus` for `"ERROR"`
- Date format: `MM/DD/YYYY` with leading zeros -- `"01/01/2024"` not `"1/1/2024"`
- `forsale` in responses is a string boolean: `"true"` / `"false"` not JSON booleans
- `getAircraftList` has no paged variant -- use filters to control result size
- `transtype: ["None"]` not `[]` to get all history transaction types
- `companyrelation` vs `relationtype` -- wrong field returns nothing (see table above)
- `getEventList` enum values are strict -- send unrecognized values and you get an `ERROR` in `responsestatus` despite HTTP 200
- `getAcCompanyFractionalReportPaged` response key is `aircraftcompfractionalrefs` -- one row per relationship per aircraft; `fractionPercentOwned: "100.00"` = actual owner, `"0.00"` = operator/manager on same aircraft; `relationship` filter is an array (`["Fractional Owner"]`)
- `getBulkAircraftExport` returns `maxpages: 0` / `currentpage: 0` when all results fit in one call -- use `max(maxpages, 1)` in your loop or you will exit immediately and miss all records
- `getBulkAircraftExport` `actiondate`/`enddate` accept full datetime strings: `"02/26/2026 10:00:00"` -- include the time component for hourly polling windows
- `getBulkAircraftExport` flat prefixed schema: `owr*` = owner, `opr*` = operator, `chp*` = chief pilot, `excbrk1*`/`excbrk2*` = brokers, `addl1-3*` = additional -- not the same as `getRegNumber` or `getRelationships`
- `getBulkAircraftExport` `forsale` is `"Y"`/`"N"` (not `"true"`/`"false"`); `datepurchased` is `YYYYMMDD` (not `MM/DD/YYYY`)
- `getRegNumber` flat `companyrelationships` uses `companyrelation` and prefixed fields (`companyname`, `contactfirstname`) -- for FBO ramp contact lookup, filter on `contacttitle` for Chief Pilot, Director of Aviation, Scheduler, Dispatcher

Payload validator script: `scripts/validate_payload.py`

---

## Enum Values

| Field | Values |
|-------|--------|
| `airframetype` | `None`, `FixedWing`, `Rotary` |
| `maketype` | `None`, `JetAirliner`, `BusinessJet`, `Turboprop`, `Piston`, `Turbine` |
| `lifecycle` | `None`, `InProduction`, `NewWithManufacturer`, `InOperation`, `Retired`, `InStorage` |
| `forsale` (request) | `"true"`, `"false"`, `""` |
| `isnewaircraft` / `ispreownedtrans` / `isinternaltrans` | `"Yes"`, `"No"`, `"Ignore"` |
| `transtype` (request categories) | `"None"` (all), `"FullSale"`, `"Lease"`, `"InternalSale"`, `"Management"`, `"Insurance"`, `"Repossession"`, `"Registration"` |

`transtype` in the **request** uses category prefixes (`"FullSale"`). In the **response** `transtype` is a full descriptive string (`"Full Sale - Retail to Retail"`). These are different.

Make names are all-caps: `"GULFSTREAM"`, `"BOMBARDIER"`, `"DASSAULT"`, `"CESSNA"`.

---

## Where to Go Next

| Need | File |
|------|------|
| Build an app / iPhone MVP / Replit integration | `references/buildkit.md` |
| Industry playbooks (brokerage, OEM, FBO, MRO, finance) | `references/vertical-playbooks.md` |
| ID system (aircraftid vs modelid vs companyid) | `references/id-glossary.md` |
| Full endpoint parameter list | `references/endpoints.md` |
| Known-good request/response pairs | `examples/` |
| Validate payload before sending | `scripts/validate_payload.py` |
| Paginate all results from any paged endpoint | `scripts/paginate.py` |
